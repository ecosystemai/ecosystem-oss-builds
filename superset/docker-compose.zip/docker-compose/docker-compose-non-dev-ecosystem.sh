docker compose -f docker-compose-non-dev-ecosystem.yml down
docker compose -f docker-compose-non-dev-ecosystem.yml pull
docker compose -f docker-compose-non-dev-ecosystem.yml up -d
